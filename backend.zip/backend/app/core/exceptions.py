from fastapi import (
    FastAPI,
    Request,
)

from fastapi.responses import JSONResponse


def register_exception_handlers(
    app: FastAPI,
) -> None:
    """
    Register global exception handlers.
    """

    @app.exception_handler(Exception)
    async def global_exception_handler(
        request: Request,
        exc: Exception,
    ):

        return JSONResponse(

            status_code=500,

            content={

                "success": False,

                "conversation_uuid": None,

                "answer": "",

                "sql": None,

                "rows": [],

                "error": str(exc),

            },

        )